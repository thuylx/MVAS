<div id="error_db">
	<h1><?php echo $heading; ?></h1>
	<?php echo $message; ?>
</div>