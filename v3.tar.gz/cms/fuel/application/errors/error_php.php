<div id="error_php" style="width: 500px; margin: auto; border: 1px solid #ddd; padding: 20px;">

	<h1 style="margin: 0; padding:0; font-family: Arial,Helvetica,sans-serif; font-size: 22px; color: #999; font-weight: normal; padding: 10px 4px 5px 0;">A PHP Error was encountered</h1>
	<p>Severity: <?php echo $severity; ?></p>
	<p>Message:  <?php echo $message; ?></p>
	<p>Filename: <?php echo $filepath; ?></p>
	<p>Line Number: <?php echo $line; ?></p>

</div>