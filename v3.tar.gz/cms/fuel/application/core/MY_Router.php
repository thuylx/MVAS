<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the Fuel_Router class */
require APPPATH."third_party/fuel/Router.php";

class MY_Router extends Fuel_Router {}