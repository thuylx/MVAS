<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the MX_Loader class */
require APPPATH."third_party/fuel/Loader.php";

class MY_Loader extends Fuel_Loader {}