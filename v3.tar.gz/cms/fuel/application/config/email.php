<?php 
$config['wordwrap'] = TRUE;