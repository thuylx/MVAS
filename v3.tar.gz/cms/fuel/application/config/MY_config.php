<?php 

date_default_timezone_set('America/Los_Angeles');

// used for development and testing
$config['dev_mode'] = TRUE;
$config['dev_email'] = '';

// for debugging... there is a hook in place to turn this on
$config['enable_profiler'] = FALSE;

/* End of file MY_config.php */
/* Location: ./application/config/MY_config.php */
