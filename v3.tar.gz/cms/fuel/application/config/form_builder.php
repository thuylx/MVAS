<?php 
$config['required_text'] = '<span class="required">{required_indicator}</span> '.lang('required_text');

/* End of file form_builder.php */
/* Location: ./application/config/form_builder.php */