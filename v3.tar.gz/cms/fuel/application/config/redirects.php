<?php 
/*
|--------------------------------------------------------------------------
| Redirects
|--------------------------------------------------------------------------
|
| Add redirects here instead of your .htaccess file with the key being
| Do NOT include beginning or trailing slashes for BOTH keys and values
| 
|	array('mypage' => 'http://www.mysite.com/my_newpage');
|
*/

$redirect = array();

/* End of file redirects.php */
/* Location: ./application/config/redirects.php */