<?php 
$config['default_ttl'] = 3600;

/* End of file strings.php */
/* Location: ./application/config/cache.php */

