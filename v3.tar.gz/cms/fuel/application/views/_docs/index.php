<h1>Site Documentation for <?=$this->config->item('site_name', 'fuel')?></h1>
<p>Here you can put your client specific documentation and it will show up in FUEL.</p>