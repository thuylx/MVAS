<?php $this->load->view('_blocks/header')?>
	
	<div id="main_inner">
		<?php echo fuel_var('body', ''); ?>
	</div>
	
<?php $this->load->view('_blocks/footer')?>
