	
	</div>
</div>
<div id="fuel_footer">
	<div id="fuel_boilerplate">
		<span id="fuel_copyright"><?=lang('fuel_copyright', date('Y'))?></span>
		<?=lang('fuel_developed_by', FUEL_VERSION)?>
	</div>
</div>
</body>
</html>