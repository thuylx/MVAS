<div id="fuel_footer">
	<?=lang('fuel_developed_by', FUEL_VERSION)?>
	<div id="fuel_copyright"><?=lang('fuel_copyright', date('Y'))?></div>
</div>
