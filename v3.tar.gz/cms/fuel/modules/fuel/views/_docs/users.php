<h1>Users</h1>
<p>The users section allows you to manage users and permissions.</p>

<img src="<?=img_path('examples/screen_users.jpg', 'user_guide')?>" class="screen" />