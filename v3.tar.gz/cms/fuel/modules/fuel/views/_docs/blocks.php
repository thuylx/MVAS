<h1>Blocks</h1>
<p>Blocks are repeatable areas of your site that you can embed into your pages using the <a href="<?=user_guide_url('helpers/fuel_helper')?>">fuel_block</a> function.</p>
<img src="<?=img_path('examples/screen_block.jpg', 'user_guide')?>" class="screen" />
