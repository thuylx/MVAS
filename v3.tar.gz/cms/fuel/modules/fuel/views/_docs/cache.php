<h1>Cache</h1>
<p>Sometimes you may make changes and not see them reflected on the site. If so, you may need to clear your site's cache.
To do that, click on the <strong>Page Cache</strong> menu item under manage and then click the <strong>Yes, clear cache</strong> button to clear your sites cache files.</p>

<img src="<?=img_path('examples/screen_cache.jpg', 'user_guide')?>" class="screen" />