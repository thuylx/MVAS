<h1>Activity Log</h1>
<p>FUEL keeps track of the activity in the system under the Activity Log. This information may be usefuel for debugging purposes. It also
provides recent activity on the dashboard.</p>

<img src="<?=img_path('examples/screen_logs.jpg', 'user_guide')?>" class="screen" />