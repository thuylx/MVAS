<h1>Dashboard</h1>
<p>The Fuel Dashboard provides a quick look into the system activity. It also provides
the ability for other modules to hook into it by simply creating a <dfn>dashboard</dfn> controller.</p>

<p>Below is an example of a Dashboard:</p>
<img src="<?=img_path('examples/screen_dashboard.jpg', 'user_guide')?>" class="screen" />
