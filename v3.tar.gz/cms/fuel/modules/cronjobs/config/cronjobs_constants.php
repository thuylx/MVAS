<?php 
define('CRONJOBS_VERSION', '0.9.2');
define('CRONJOBS_FOLDER', 'cronjobs');
define('CRONJOBS_PATH', MODULES_PATH.CRONJOBS_FOLDER.'/');