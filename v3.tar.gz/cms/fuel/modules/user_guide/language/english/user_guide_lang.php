<?php
$lang['module_user_guide'] = 'User Guide';