<?php 
define('USER_GUIDE_VERSION', '0.9.2');
define('USER_GUIDE_FOLDER', 'user_guide');
define('USER_GUIDE_PATH', MODULES_PATH.USER_GUIDE_FOLDER.'/');