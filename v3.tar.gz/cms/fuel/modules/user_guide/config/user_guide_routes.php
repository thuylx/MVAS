<?php 
$route[FUEL_ROUTE.'tools/user_guide'] = 'user_guide';
$route[FUEL_ROUTE.'tools/user_guide/(:any)'] = 'user_guide/$1';
