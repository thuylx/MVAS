<h1>My Helper</h1>
<p>This helper is automatically loaded. Site specific functions should be placed in this helper file.</p>