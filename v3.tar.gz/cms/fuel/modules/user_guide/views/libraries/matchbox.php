<h1>Matchbox</h1>
<p><a href="http://code.google.com/p/matchbox/" target="_blank">Matchbox</a>, developed by <a href="http://codeigniter.com/forums/member/39666/" target="_blank">Zacharias Knudsen</a>, 
extends CodeIgniter to allow for module  development. The CodeIgniter libraries <dfn>Loader</dfn>, <dfn>Router</dfn>, <dfn>Config</dfn> and <dfn>Language</dfn>
are either overwritten or extended to allow for module development and are located in the <dfn>application/libraries/</dfn> folder.
</p>