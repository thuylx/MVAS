<h1>Template</h1>
<p>The <a href="http://codeigniter.com/forums/viewthread/67028/" target="_blank">Template</a> library used by FUEL, 
was developed by <a href="http://codeigniter.com/forums/member/45875/" target="_blank">wiredesignz</a>.</p>
