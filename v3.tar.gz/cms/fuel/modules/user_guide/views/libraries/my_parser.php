<h1>MY_parser Class</h1>
<p>FUEL CMS uses <a href="http://philsturgeon.co.uk" target="_blank">Phil Sturgeon's</a> extended Parser class so 
that the <a href="http://dwoo.org">Dwoo templating engine</a> could easily integrate.</p>