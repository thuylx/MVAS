<h1>Cache</h1>
<p>The <a href="http://codeigniter.com/forums/viewthread/57117/" target="_blank">Cache</a> library used by FUEL, 
was developed by <a href="http://codeigniter.com/forums/member/47411/" target="_blank">Al James</a>
and allows for greater control of caching files beyond CodeIgniter's 
<a href="http://codeigniter.com/user_guide/general/caching.html" target="_blank">Caching class</a>.</p>