<h1>SimplePie</h1>
<p>FUEL uses the popular <a href="http://simplepie.org/" target="_blank">SimplePie</a> library to include
RSS information into it's Dashboard.</p>