<h1>Server Requirements</h1>
<ul>
	<li>Apache server with .htaccess.</li>
	<li><a href="http://www.php.net" target="_blank">PHP</a> version 5.1.6 or greater.</li>
	<li>A <a href="http://www.mysql.com" target="_blank">MySQL 4+</a> database if using the FUEL admin. Currently does not support other databases.</li>
</ul>