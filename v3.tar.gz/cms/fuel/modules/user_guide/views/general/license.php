<h1>License</h1>
<p>FUEL CMS is released under the Apache License v2.0. You can read the license here: 
<a href="http://www.apache.org/licenses/LICENSE-2.0" target="_blank">http://www.apache.org/licenses/LICENSE-2.0</a></p>
