<h1>Contribute</h1>
<p>If you find this project useful and want it to succeed, please consider 
contributing your time, energy and/or wisdom by <?=safe_mailto('info@getfuelcms.com', 'sending us an email')?> regarding how 
you want to contribute or simply by sending us your suggestions, feedback and bugs (with hopefully a way to fix :-).</p>