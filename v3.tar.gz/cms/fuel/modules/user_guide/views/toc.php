<a href="http://www.getfuelcms.com" target="_blank"><img src="<?=img_path('fuel_logo.png', 'user_guide')?>" id="fuel_logo" title="Visit getfuelcms.com" alt="FUEL CMS" /></a>
<h1>Table of Contents</h1>

<?php $this->load->view('_blocks/toc')?>